package miu.edu.waa.onlineMiniMarket;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMiniMarketApplicationTests {

	@Test
	void contextLoads() {
	}

}
