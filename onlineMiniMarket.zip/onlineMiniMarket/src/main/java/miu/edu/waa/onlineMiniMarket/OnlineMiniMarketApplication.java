package miu.edu.waa.onlineMiniMarket;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineMiniMarketApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineMiniMarketApplication.class, args);
	}

}
